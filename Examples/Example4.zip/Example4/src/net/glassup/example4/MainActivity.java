package net.glassup.example4;


import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import glassup.service.GlassUpAgent;
import glassup.service.GlassUpAgentInterface.ConnectionListener;
import android.os.Bundle;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {

	//Used to send the message to the handler class
	public final int MSG_WHAT_SEND_CONFIG	= 1;
	
	//Used to get the connection state and the configuration state.
	public static boolean mServiceConnected;
	public static boolean mAppConfigured;
	
	/*The GlassUp agent and its listners*/
	public static GlassUpAgent mAgent;
	AgentEventListner eventListener;
	AgentContentListener contentResultListener;
	ConnectionListener mConnListener;
	ConfigurationHandler mHandler;
	
	/*The conter id*/
	int counter=0;
	static int indexImage =0;
	public static Bitmap[] images;
	Timer timer;
	Button btnPlay,btnStop;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Toast.makeText(getApplicationContext(), "Set the Min & Max Persisting time to 1 second on the GlassUp Service!", Toast.LENGTH_LONG).show();
		
		btnPlay = (Button) findViewById(R.id.btnPlay);
		btnPlay.setOnClickListener(this);
		
		btnStop = (Button)	findViewById(R.id.btnStop);
		btnStop.setOnClickListener(this);
		images = makeRatatedBitmaps();
		
		/*The listners declarations*/
		eventListener = new AgentEventListner();
		contentResultListener = new AgentContentListener();
		mConnListener = new mConnectionListener();
		mAgent = new GlassUpAgent();
		/*The agent follows the Activity lifecycle*/
		mAgent.onCreate(this);
		
		/*Set the agent's listners*/
		mAgent.setEventListener(eventListener);
		mAgent.setContentResultListener(contentResultListener);
		mAgent.setConnectionListener(mConnListener);
		
		/*Declare the configuration handler*/
		mHandler = new ConfigurationHandler();
		
		mAppConfigured = mAgent.isConfigured(); // the agent is configured?
		if (!mAppConfigured){		
			/*Not configured*/
			Log.d("TAG","App not configured, Scheduling send configure");
			mAppConfigured = false;
			/*Send the configuration message*/
			mHandler.sendEmptyMessage(MSG_WHAT_SEND_CONFIG);
		}	
		else {
			/*Already configured*/
			Log.d("TAG","App Already configured");
			mAppConfigured = true;
			Toast.makeText(getApplicationContext(), "App already configured", Toast.LENGTH_LONG).show();
		}
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		/*The agent follows the Activity lifecycle*/
		mAgent.onDestroy();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		/*The agent follows the Activity lifecycle*/
		mAgent.onPause();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		/*The agent follows the Activity lifecycle*/
		mAgent.onResume();
	}
	
	private Bitmap[] makeRatatedBitmaps(){
		int degrees=-45;
		ArrayList<Bitmap> rotated = new ArrayList<Bitmap>();
		Bitmap source = BitmapFactory.decodeResource(this.getResources(), R.drawable.ic_android);
		for(;degrees<=315;){
			rotated.add(RotateBitmap(source, degrees+=45));
		}
		return rotated.toArray(new Bitmap[rotated.size()]);
	}
	
	public static Bitmap RotateBitmap(Bitmap source, float angle)
	{
	      Matrix matrix = new Matrix();
	      matrix.postRotate(angle);
	      Bitmap scaledBitmap =  Bitmap.createScaledBitmap(source,100,100,true);
	    
	      return Bitmap.createBitmap(scaledBitmap, 0, 0,scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix, true);
	}

	@Override
	public void onClick(View v) {
		switch(v.getId()){
		case R.id.btnPlay:
				timer = new Timer();
				timer.schedule(new TimerTask() {
					
					@Override
					public void run() {
						mAgent.sendContent(counter++, 1, new String[]{String.valueOf(indexImage)},null );
						if(indexImage++ > 7) indexImage =0 ;
					}
				}, 1000, 1000);
			break;
		case R.id.btnStop:
			timer.cancel();
			break;
		}
		
	}

}
