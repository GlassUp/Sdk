package net.glassup.example4;


import glassup.service.GlassUpAgentInterface.ContentResultListener;

/**
 * 
 * @author Blescia Antonio
 * The AngentContentListner handles the results when a content is sended to the device
 */
public class AgentContentListener implements ContentResultListener {

	//Called when a result is available
	@Override
	public void onContentResult(int contentId, int status, String statusMessage) {
		// TODO Auto-generated method stub
		
	}

}
