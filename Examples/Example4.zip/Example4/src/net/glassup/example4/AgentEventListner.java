package net.glassup.example4;

import android.util.Log;
import glassup.service.GlassUpAgentInterface.EventListener;
import glassup.service.GlassUpEvent;

/**
 * 
 * @author Blescia Antonio
 * The AgentEventListner handles the events produced by the buttons touch on the Glass
 */
public class AgentEventListner implements EventListener {

	//Called when a button event is fired
	@Override
	public void onButtonEvent(GlassUpEvent event, int contentId) {
		
		
	}

	@Override
	public void onEvent(GlassUpEvent event) {
		// TODO Auto-generated method stub
		
	}

}
