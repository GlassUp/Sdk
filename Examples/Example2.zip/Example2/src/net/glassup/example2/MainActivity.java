package net.glassup.example2;


import java.util.Timer;
import java.util.TimerTask;

import glassup.service.GlassUpAgent;
import glassup.service.GlassUpAgentInterface.ConnectionListener;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.widget.Toast;

public class MainActivity extends Activity {

		//Used to send the message to the handler class
		public final int MSG_WHAT_SEND_CONFIG	= 1;
		
		//Used to get the connection state and the configuration state.
		public static boolean mServiceConnected;
		public static boolean mAppConfigured;
		
		/*The GlassUp agent and its listners*/
		public static GlassUpAgent mAgent;
		AgentEventListner eventListener;
		AgentContentListener contentResultListener;
		ConnectionListener mConnListener;
		ConfigurationHandler mHandler;
		
		/*The conter id*/
		int counter=0;

		//Contains the name of images
		public static String[] names;
		//The index of image and name to shows
		public static int indexNames=0;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Toast.makeText(getApplicationContext(), "Set the Min & Max Persisting time to 1 second on the GlassUp Service!", Toast.LENGTH_LONG).show();
		/*The listners declarations*/
		eventListener = new AgentEventListner();
		contentResultListener = new AgentContentListener();
		mConnListener = new mConnectionListener();
		mAgent = new GlassUpAgent();
		/*The agent follows the Activity lifecycle*/
		mAgent.onCreate(this);
		
		/*Set the agent's listners*/
		mAgent.setEventListener(eventListener);
		mAgent.setContentResultListener(contentResultListener);
		mAgent.setConnectionListener(mConnListener);
		
		/*Declare the configuration handler*/
		mHandler = new ConfigurationHandler();
		
		mAppConfigured = mAgent.isConfigured(); // the agent is configured?
		if (!mAppConfigured){		
			/*Not configured*/
			Log.d("TAG","App not configured, Scheduling send configure");
			mAppConfigured = false;
			/*Send the configuration message*/
			mHandler.sendEmptyMessage(MSG_WHAT_SEND_CONFIG);
		}	
		else {
			/*Already configured*/
			Log.d("TAG","App Already configured");
			mAppConfigured = true;
			Toast.makeText(getApplicationContext(), "App already configured", Toast.LENGTH_LONG).show();
		}
		//Get the list of names from app resources
		names = getResources().getStringArray(R.array.names);
		
		//This timer shows the every 1 second a selected content on the device
		Timer t = new Timer();
		t.schedule(new TimerTask() {
			
			@Override
			public void run() {
				if(mAppConfigured) 
				mAgent.sendContent(counter++, 2, new String[]{String.valueOf(indexNames)}, new String[]{names[indexNames]});
				
			}
		}, 0, 1000);
		
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		/*The agent follows the Activity lifecycle*/
		mAgent.onDestroy();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		/*The agent follows the Activity lifecycle*/
		mAgent.onPause();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		/*The agent follows the Activity lifecycle*/
		mAgent.onResume();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

}
