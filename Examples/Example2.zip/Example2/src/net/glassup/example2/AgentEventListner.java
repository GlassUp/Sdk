package net.glassup.example2;

import glassup.service.GlassUpAgentInterface.EventListener;
import glassup.service.GlassUpEvent;

/**
 * 
 * @author Blescia Antonio
 * The AgentEventListner handles the events produced by the buttons touch on the Glass
 */
public class AgentEventListner implements EventListener {
	private static int lastContentId=0;
	
	//Called when a button event is fired
	@Override
	public void onButtonEvent(GlassUpEvent event, int contentId) {
		if(lastContentId!= contentId) //Get only one button pression per activity
		switch ((int)event.values[0]) { //Get the button
		case 0: //If plus
			if(MainActivity.indexNames>=3){MainActivity.indexNames =0;} 
			else{MainActivity.indexNames++;}
			break;
		case 1: //if minus
			if(MainActivity.indexNames<=0){MainActivity.indexNames =3;}
			else{MainActivity.indexNames--;}
		default:
			break;
		}
		lastContentId = contentId; //save the last contentId
		
		
	}

	@Override
	public void onEvent(GlassUpEvent event) {
		
	}

}
