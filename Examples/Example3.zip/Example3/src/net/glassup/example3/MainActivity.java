package net.glassup.example3;

import net.glassup.example3.AgentContentListener;
import net.glassup.example3.AgentEventListner;
import net.glassup.example3.ConfigurationHandler;
import net.glassup.example3.mConnectionListener;
import glassup.service.GlassUpAgent;
import glassup.service.GlassUpAgentInterface.ConnectionListener;

import android.os.Bundle;
import android.os.SystemClock;
import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Rect;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	
	
	//Used to send the message to the handler class
	public final int MSG_WHAT_SEND_CONFIG	= 1;
	
	//Used to get the connection state and the configuration state.
	public static boolean mServiceConnected;
	public static boolean mAppConfigured;
	
	/*The GlassUp agent and its listners*/
	public static GlassUpAgent mAgent;
	AgentEventListner eventListener;
	AgentContentListener contentResultListener;
	ConnectionListener mConnListener;
	ConfigurationHandler mHandler;
	
	/*The conter id*/
	int counter=0;
	
	
	private Chronometer chronometer;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Toast.makeText(getApplicationContext(), "Set the Min & Max Persisting time to 1 second on the GlassUp Service!", Toast.LENGTH_LONG).show();
		chronometer = (Chronometer) findViewById(R.id.chronometer);
		chronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
			
			@Override
			public void onChronometerTick(Chronometer chronometer) {
				mAgent.sendConfiguration(new Bitmap[]{drawTextToBitmap(chronometer.getText().toString())});
				mAgent.sendContent(counter++, 0, null,new String[]{chronometer.getText().toString()});
				
			}
		});
		((Button) findViewById(R.id.start_button)).setOnClickListener(this);
        
		((Button) findViewById(R.id.stop_button)).setOnClickListener(this);
		
		/*The listners declarations*/
		eventListener = new AgentEventListner();
		contentResultListener = new AgentContentListener();
		mConnListener = new mConnectionListener();
		mAgent = new GlassUpAgent();
		/*The agent follows the Activity lifecycle*/
		mAgent.onCreate(this);
		
		/*Set the agent's listners*/
		mAgent.setEventListener(eventListener);
		mAgent.setContentResultListener(contentResultListener);
		mAgent.setConnectionListener(mConnListener);
		
		/*Declare the configuration handler*/
		mHandler = new ConfigurationHandler();
		
		mAppConfigured = mAgent.isConfigured(); // the agent is configured?
		if (!mAppConfigured){		
			/*Not configured*/
			Log.d("TAG","App not configured, Scheduling send configure");
			mAppConfigured = false;
			/*Send the configuration message*/
			mHandler.sendEmptyMessage(MSG_WHAT_SEND_CONFIG);
		}	
		else {
			/*Already configured*/
			Log.d("TAG","App Already configured");
			mAppConfigured = true;
			Toast.makeText(getApplicationContext(), "App already configured", Toast.LENGTH_LONG).show();
		}
		
		
		
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		/*The agent follows the Activity lifecycle*/
		mAgent.onDestroy();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		/*The agent follows the Activity lifecycle*/
		mAgent.onPause();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		/*The agent follows the Activity lifecycle*/
		mAgent.onResume();
	}
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	 @Override
     public void onClick(View v) {
            switch(v.getId()) {
            case R.id.start_button:
                   chronometer.setBase(SystemClock.elapsedRealtime());
                   chronometer.start();
                   break;
           case R.id.stop_button:
                  chronometer.stop();
                  break;
           }
    }

	 public  Bitmap drawTextToBitmap(String gText) {
		    Resources resources = getApplicationContext().getResources();
		    float scale = resources.getDisplayMetrics().density;
		    Bitmap.Config conf = Bitmap.Config.ALPHA_8; 
		     Bitmap bitmap= Bitmap.createBitmap(320, 240, conf); 

		    android.graphics.Bitmap.Config bitmapConfig =
		            bitmap.getConfig();
		    // set default bitmap config if none
		    if(bitmapConfig == null) {
		        bitmapConfig = android.graphics.Bitmap.Config.ARGB_8888;
		    }
		    // resource bitmaps are imutable, 
		    // so we need to convert it to mutable one
		    bitmap = bitmap.copy(bitmapConfig, true);

		    Canvas canvas = new Canvas(bitmap);
		    // new antialised Paint
		    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		    // text color - #000000
		    paint.setColor(Color.rgb(0, 0, 0));
		    // text size in pixels
		    paint.setTextSize((int) (25 * scale));
		    // text shadow
		    paint.setShadowLayer(1f, 0f, 1f, Color.WHITE);

		    // draw text to the Canvas center
		    Rect bounds = new Rect();
		    paint.setTextAlign(Align.CENTER);

		    paint.getTextBounds(gText, 0, gText.length(), bounds);
		    int x = (bitmap.getWidth() - bounds.width())/2;
		    int y = (bitmap.getHeight() + bounds.height())/2; 

		    canvas.drawText(gText, x * scale, y * scale, paint);

		    return bitmap;
		}
}
